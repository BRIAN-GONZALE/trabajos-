<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>mayoria_edad_</title>
</head>
<body>
<fieldset>
<legend>control de ingreso ala montaña rusa</legend>
<form action = "index.php" method= "post">
    <input type="number" name="edad" id="">
<input type="submit" value="calcular">


</form>
</fieldset>
    
</body>
</html>

<?php
if ($post){
$edad = $post ['edad'];
$estaura = $post ['estatura'];
if ($edad < 18 && $estaura < 1.90) 
echo"no cumple con lo que se pide, no puede  ingresar ala montaña rusa";
elseif ($edad > 18 && $estaura > 1.90)
echo "si cumplis con lo que se pide, si puede ingreasar ala montaña rusa";}
?>
