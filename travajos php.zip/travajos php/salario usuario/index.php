<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>nombre_usuario_ingrese_su_salario_y_años_trabajando</title>
</head>
<body>
    <fieldset>
    <legend>nombre de nombre_usuario_ingrese_su_salario_y_años_trabajando</legend>
    <from action="indec.php" method= "post">
        <input type="usuario" name="salario" id="">
        <input type="submit" value="calcular años travajados">
</from>
</fieldset>
    
</body>
</html>

<?php
if ($post){
$sueldo = $post ['sueldo'];


if ($años_travajados >=10 && $años_travajados <= 15 && $salario<= 350000) 
echo"el señor $nombre,cuenta con un salario de: $salario y lleva travajando para nosotros $años_travajados. le corresponde vacaciones pagas ";
elseif (10 && $salario > )
echo "el señor $nombre,cuenta con un salario de: $salario y lleva travajando para nosotros $años_travajados. no tendra vacaciones pagas";}
?>