<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>sueldo_empleado</title>
</head>
<body>
<fieldset>
<legend>aumento de sueldo_empleado</legend>
<form action="indec.php" method= "post">
    <input type="empleado" name="sueldo" id="">
    <input tipe="submit" value="calcular sueldo">
</form>
</fieldset>
    
</body>
</html>

<?php

if ($_POST)
$sueldo = 350000;


if ($sueldo >= 320000 && $sueldo <= 500000) {
    $aumento = $sueldo * 0.05;
} else {
    $aumento = $sueldo * 0.08;
}

$nuevo_sueldo = $sueldo + $aumento;


echo "Su sueldo es: $" . number_format($sueldo, 2) . " y su aumento es: $" . number_format($nuevo_sueldo, 2);

?>



